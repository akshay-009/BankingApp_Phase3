package com.fis.bankingapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankingapp.model.Account;

public interface AccountDao extends JpaRepository<Account,Long> {
	// This is the interface in dao layer for account transactions
//	public String createAccount(Account account);
//	public Account getAccount(long getAcc); 
//	public List<Account> getAllAccounts();
//	public String updateAccount(Account account);
//	public String deleteAccount(long getacc);
	
	@Query("Update Account set balance=balance+?2 where accountNumber=?1")
	@Modifying
	public void deposit(long getAcc, double depositAmount);
	
	@Query("Update Account set balance=balance-?2 where accountNumber=?1")
	@Modifying
	public void withdraw(long getAcc, double withdrawAmount); 
	// public String fundTransfer(long fromAcc, long toAcc, double amount) throws AccountNotFound, NotEnoughBalance;
	
	//public double interestEarned(long getAcc,Date todaydate);


}
