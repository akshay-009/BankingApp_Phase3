package com.fis.bankingapp.model;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

//import javax.validation.constraints.Max;
//{
//    "accopendate": "2023-11-02",
//    "accounttype": "Savings",
//    "balance": 0,
//    "branch": "Aundh"
//}
@Entity
@Table(name="Account_details")

public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="acc")
	private long accountNumber;
// Here i took ManytoOne because one customer can have many accounts in the same bank.
	@ManyToOne
	@JoinColumn(name = "id") // id is the foreign key.
	private Customer customer;
	
//	private long customerId;
	@NotBlank(message="accounttype cannot be null or whitespace")
	private String accounttype;
	
	private LocalDate accopendate=LocalDate.now();
	private double balance;
    @NotBlank(message="accounttype cannot be null or whitespace")
	private String branch;
	
	

	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Customer getCustomer() {
	        return customer;
	    }

    public void setCustomer(Customer customer) {
	        this.customer = customer;
	    }
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public LocalDate getAccopendate() {
		return accopendate;
	}
	public void setAccopendate(LocalDate accopendate) {
		this.accopendate = accopendate;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	

	@Override
	public String toString() {
		return String.format(
				"Account [accountNumber=%s, customer=%s, accounttype=%s, accopendate=%s, balance=%s, branch=%s]",
				accountNumber, customer, accounttype, accopendate, balance, branch);
	}
	public Account(long accountNumber, Customer customer,
			@NotBlank(message = "accounttype cannot be null or whitespace") String accounttype, LocalDate accopendate,
			double balance, @NotBlank(message = "accounttype cannot be null or whitespace") String branch) {
		super();
		this.accountNumber = accountNumber;
		this.customer = customer;
		this.accounttype = accounttype;
		this.accopendate = accopendate;
		this.balance = balance;
		this.branch = branch;
	}
	public Account( long accountNumber, String accounttype, LocalDate accopendate, double balance,
			String branch) {
		super();
//		this.customerId = customerId;
		this.accountNumber = accountNumber;
		this.accounttype = accounttype;
		this.accopendate = accopendate;
		this.balance = balance;
		this.branch = branch;
	}
	
	public Account() {
		
	}

}
