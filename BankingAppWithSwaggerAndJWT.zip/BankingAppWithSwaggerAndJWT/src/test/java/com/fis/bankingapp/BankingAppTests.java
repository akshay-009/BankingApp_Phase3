package com.fis.bankingapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.NotEnoughBalance;
import com.fis.bankingapp.model.Account;
import com.fis.bankingapp.model.Customer;
import com.fis.bankingapp.service.AccountService;
import com.fis.bankingapp.service.CustomerService;
import com.fis.bankingapp.service.TransactionService;

@SpringBootTest
class BankingAppTests {
	
	@Autowired
	CustomerService service;
	@Autowired
	AccountService service1;
	@Autowired
	TransactionService service2;
//
//	@Test
//	void contextLoads() {
//	}
	@Test
		public void testcreateCustomer() {
			Customer customer = new Customer(123,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
			String msg = service.createCustomer(customer);
			assertEquals("Customer Created Successfully",msg);
		}
	
	@Test
	   public void testcreateAccount() {
			Customer customer = new Customer(12,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
			Account account = new Account( 111, customer, "Savings" ,LocalDate.now(), 1234, "Aundh");
			String msg = service1.createAccount(account);
			assertEquals("Account Created Successfully",msg);
	}
	
	@Test
		public void testupdateAccount() {
		Customer customer = new Customer(12,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
		Account account = new Account( 111, customer, "Savings" ,LocalDate.now(), 1234, "kukatpally");
		String msg = service1.updateAccount(account);
		assertEquals("Account Updated Successfully",msg); 	
	}
	
	@Test
		public void testdeleteAccount() throws AccountNotFound {
		String msg = service1.deleteAccount(27);
		assertEquals("Account Deleted Successfully",msg);
	}
	
	@Test
		public void testdeposit() throws AccountNotFound {
		String msg = service1.deposit(19, 1000);
		assertEquals("Amount Deposited Successfully",msg);
	}
	
	@Test
		public void testwithdraw() throws AccountNotFound, NotEnoughBalance {
		String msg = service1.withdraw(19, 500);
		assertEquals("Amount Withdrawed Successfully",msg);
	}
	
	@Test
		public void testfundTransfer() throws AccountNotFound, NotEnoughBalance {
		String msg = service1.fundTransfer(19, 8, 0);
		assertEquals("Fund Transfer Successfully",msg);
	}
	

}
